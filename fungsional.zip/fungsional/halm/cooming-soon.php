<style>
    .padding100
    {
        padding: 130px;
    }
</style>
<?php
    include './fungsional/konfig/headerUdahLogin.php';
?>
<section class="padding100">
    <div class="container padding100">
        <div class="row">
            <div class="col-md">
                <h1 align='center'>COOMING SOON</h1>
               
            </div>
        </div>
    </div>
</section>