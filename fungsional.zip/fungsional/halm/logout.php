<?php

    setcookie("userEmail", "");

    echo
    "
    <script>
        window.location='index.php';
    </script>
    ";

?>