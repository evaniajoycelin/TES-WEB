<?php
    include './fungsional/konfig/header.php';

    echo
    "
        <br><br><br><br>
    ";
    include './fungsional/konfig/kontak-kami.php';
    include './fungsional/konfig/footer.php';
?>