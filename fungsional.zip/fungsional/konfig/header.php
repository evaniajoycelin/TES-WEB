<?php

    if (empty($iduser)) 
    {
        include './fungsional/konfig/headerBelumLogin.php';
    }
    else
    {
        include './fungsional/konfig/headerUdahLogin.php';
    }

?>